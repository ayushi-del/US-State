import turtle
import pandas

screen = turtle.Screen()
screen.title("US State Game")
image = "blank_states_img.gif"
screen.addshape(image)
turtle.shape(image)
data = pandas.read_csv("50_states.csv")
all_states = data.state.to_list()
guessed_state = []
t = 0
while len(guessed_state) < 50:
    guess = screen.textinput(title=f"{t}/50 state correct", prompt="Guess the state").title()
    if guess == "Exit":
        break
    if guess in all_states:
        t += 1
        answer = turtle.Turtle()
        answer.penup()
        answer.hideturtle()
        answer.color("Black")
        state_data = data[data.state == guess]
        answer.goto(x=int(state_data.x), y=int(state_data.y))
        answer.write(state_data.state.item())
        guessed_state.append(guess)
missing_state = []
for state in all_states:
    if state not in guessed_state:
        missing_state.append(state)
        print(state)
state_to_learn_data = pandas.DataFrame(missing_state)
state_to_learn_data.to_csv("state_to_learn.csv")

